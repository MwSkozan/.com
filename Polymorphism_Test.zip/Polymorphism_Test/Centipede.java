package Polymorphism_Test;

public class Centipede extends Animal {




    public Centipede() {
        super(100);

    }

    @Override
    public String getName() {
        return "Centipede";
    }

    @Override
    public String getNoise() {
        return "Centipedes don’t make noise." ;
    }
}
