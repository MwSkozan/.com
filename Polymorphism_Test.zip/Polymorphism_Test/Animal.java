package Polymorphism_Test;

public class Animal {

    // declaring variables
    private String Name ="Animal";
    private String Noise;
    private int NumLegs;

    public Animal(int NumLegs) {
        this.NumLegs = NumLegs;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getNoise() {
        return Noise;
    }

    public void setNoise(String noise) {
        Noise = noise;
    }

    public int getNumLegs() {
        return NumLegs;
    }

    public void setNumLegs(int numLegs) {
        NumLegs = numLegs;
    }
}
