package Polymorphism_Test;

public class Cat extends Animal {


    // default Constructor
    public Cat() {
        super(4);
        this.setName("Cat");
        this.setNoise("Meow");

    }

    @Override
    public String toString() {
        return "An adorable kitten.";
    }
}
